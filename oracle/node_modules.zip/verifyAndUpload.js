const hre = require("hardhat");
const fs = require("fs");

// 载入药品价格与医保规则
const drugPrices = JSON.parse(fs.readFileSync("./oracle/data/drugPrices.json", "utf8"));
const policyRules = JSON.parse(fs.readFileSync("./oracle/data/policyRules.json", "utf8"));

// 替换为你部署的合约地址
const CONTRACT_ADDRESS = "0x123...";

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const contract = await hre.ethers.getContractAt("SimpleFraudDetector", CONTRACT_ADDRESS);

  // 假设你知道要检查的 recordId
  const recordId = "0xabcdef1234567890...";  // bytes32

  const record = await contract.registry().then(reg => reg.records(recordId));
  console.log("Record loaded:", record);

  if (!record.pharmacyConfirmed) {
    console.log("⛔ 未药房确认，不能报销");
    return;
  }

  // 每种药品逐项验证价格限制（示例）
  let isValid = true;
  for (let i = 0; i < record.medicines.length; i++) {
    const drugName = record.medicines[i];
    const amount = record.medicineAmounts[i];

    const unitPrice = drugPrices[drugName];
    if (!unitPrice) {
      console.log(`⛔ 未知药品：${drugName}`);
      isValid = false;
      break;
    }

    const totalPrice = unitPrice * amount;
    if (totalPrice > 500) { // 假设医保上限为500
      console.log(`⛔ 药品 ${drugName} 超过医保报销上限`);
      isValid = false;
      break;
    }
  }

  // 上传判断结果
  const tx = await contract.setReimbursementStatus(recordId, isValid);
  await tx.wait();
  console.log(`✅ 报销状态写入链上: ${isValid}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
