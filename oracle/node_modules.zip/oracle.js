const hre = require("hardhat");
const fs = require("fs");

const contractAddress = "部署后的AutoReimbursement地址"; // 手动替换

async function main() {
  const [oracle] = await hre.ethers.getSigners(); // 默认 signer 即 Oracle 角色
  const contract = await hre.ethers.getContractAt("AutoReimbursement", contractAddress);

  const recordId = hre.ethers.utils.keccak256(hre.ethers.utils.toUtf8Bytes("record123"));

  const drugPrices = JSON.parse(fs.readFileSync("./oracle/data/drugPrices.json", "utf8"));
  const policyRules = JSON.parse(fs.readFileSync("./oracle/data/policyRules.json", "utf8"));

  const record = {
    region: "Jiangsu",
    hospitalTier: "Tertiary",
    consultationTime: 30,
    drugNames: ["Amoxicillin"],
    drugQuantities: [2],
    diseaseCategory: "Respiratory"
  };

  const key = `${record.region}-${record.hospitalTier}`;
  const rule = policyRules[key];

  if (!rule || !rule.covered) {
    console.log("❌ 不在医保覆盖范围");
    return;
  }

  let total = 0;
  for (let i = 0; i < record.drugNames.length; i++) {
    total += (drugPrices[record.drugNames[i]] || 0) * record.drugQuantities[i];
  }
  total += record.consultationTime * rule.consultationRatePerMinute;
  const approved = total * rule.reimbursementRate >= 100; // 示例判断逻辑

  const tx = await contract.setReimbursementStatus(recordId, approved);
  await tx.wait();
  console.log("✅ 写入结果成功");
}

main();
