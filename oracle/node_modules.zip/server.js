const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3001;

// Load data on startup
const reimbursements = JSON.parse(fs.readFileSync('./data/reimbursements.json'));
const policyRules = JSON.parse(fs.readFileSync('./data/policyRules.json'));
const drugPrices = JSON.parse(fs.readFileSync('./data/drugPrices.json'));


app.get('/reimbursements', (req, res) => {
  res.json(reimbursements);
});

app.get('/policy-rules', (req, res) => {
  res.json(policyRules);
});

app.get('/drug-prices', (req, res) => {
  res.json(drugPrices);
});

app.get('/reimbursements/:id/expected-amount', (req, res) => {
    const id = req.params.id;
    const record = reimbursements[id];
  
    if (!record) {
      return res.status(404).json({ error: 'Reimbursement record not found.' });
    }
  
    const region = record.region;
    const tier = record.hospitalTier.replace(/\s+/g, ''); // "Tier 2" => "Tier2"
    const key = `${region}-${tier}`;
    const rule = policyRules[key];
  
    if (!rule) {
      return res.status(400).json({ error: `Policy rule not found for key: ${key}` });
    }
  
    // Step 1: Consultation cost
    const consultationCost = record.consultationTime * rule.consultationRatePerMinute;
  
    // Step 2: Drug cost
    let drugCost = 0;
    for (const drug of record.drugList) {
      const price = drugPrices[drug.name];
      if (!price) {
        return res.status(400).json({ error: `Price not found for drug: ${drug.name}` });
      }
      drugCost += drug.qty * price;
    }
  
    // Step 3: Expected amount
    const totalCost = consultationCost + drugCost;
    const expectedAmount = totalCost * (rule.reimbursementRate / 100);
  
    return res.json({
      id,
      consultationCost,
      drugCost,
      totalCost,
      reimbursementRate: rule.reimbursementRate,
      expectedAmount: Math.round(expectedAmount)
    });
  });


app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
